Hi all,

    Please complete following 2 tasks.

1. Use the neural network concept to solve for the weights of linear regression.

2. Plot the resulting residual plot.

Additionally, you can see the link 'https://github.com/TommyHuang821/Deep-Learning-API-example/blob/master/TensorFlow/TF%20%E7%AF%84%E4%BE%8B%20II%20(Regression).md' for task 1.

With warm regards,
